function notFound(req, res) {
    res.status(404).send('not found page');
}

module.exports = notFound;