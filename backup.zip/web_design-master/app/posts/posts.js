// Публикации


class Posts {

    constructor() {

    }

    get() {

    }

    create() {

    }

    update() {

    }

    delete() {

    }

}

module.exports = Posts;