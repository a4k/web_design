const express = require('express');
const users = express.Router();

//const Token = require('../token/token');
//const token = new Token();

class User {
    constructor() {

    }

    get (req, res) {
        res.status(200).send({
            status: true,
            token: 'sdfsdf',
        });
    }

    // Авторизация
    signIn (req, res) {

        if(!req.body) return res.sendStatus(400);

        var user = {
            login: req.body.login,
            password: req.body.password,
        };

        var isLogged = true;

        if(isLogged) {

            res.status(200).send({
                status: true,
                token: '45555',
            });
        } else {
            res.status(401).send({
                status: false,
                message: 'Invalid authorization data',
            })
        }
    }


}





module.exports = User;