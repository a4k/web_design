const express = require('express');
const router = express.Router();

const Users = require('./users/users');
const users = new Users();

router.get('/', (req, res) => {
    res.send('okay');
});


router.get('/api/auth', users.get);
router.post('/api/auth', users.signIn);


module.exports = router;