var config = module.exports;

config.site = {
    port: 8081,
    //ip: '127.0.0.1',
};

config.db = {
    port: 27017,
    host: 'localhost',
    user: '',
    pass: '',
};

